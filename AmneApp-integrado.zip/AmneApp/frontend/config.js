// La pantalla la sirve el propio servidor Go (misma dirección y puerto), por eso BASE queda vacío.
// Para ver una demostración sin servidor cambie MODE a "mock".
window.APP_CONFIG = { MODE: "live", BASE: "" };
