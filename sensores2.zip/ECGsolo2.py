import network
import socket
import time
import json
from machine import Pin, ADC

# ==========================================
# 1. CONFIGURACIÓN DE PINES ECG
# ==========================================
PIN_ANALOGO = 34
PIN_LO_PLUS = 25
PIN_LO_MINUS = 26

adc = ADC(Pin(PIN_ANALOGO))
adc.atten(ADC.ATTN_11DB)

lo_plus = Pin(PIN_LO_PLUS, Pin.IN)
lo_minus = Pin(PIN_LO_MINUS, Pin.IN)

# ==========================================
# 2. CONFIGURACIÓN WIFI (ACCESS POINT)
# ==========================================
ap = network.WLAN(network.AP_IF)
ap.active(True)
ap.config(
    essid="ampeapp",
    password="proyectouniversidad"
)

while not ap.active():
    pass

print("WiFi AP activo (ampeapp)")
print("IP del Servidor:", ap.ifconfig()[0])

# ==========================================
# 3. INTERFAZ WEB UNIFICADA
# ==========================================
html = """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Monitor Clínico Integrado - Pacientes 1 y 2</title>
<style>
body {
    font-family: 'Courier New', Courier, monospace;
    text-align: center;
    background: #111;
    color: #2ecc71;
    margin: 0;
    padding: 10px;
}
.grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 10px;
    margin-top: 10px;
}
.card {
    background: #222;
    padding: 12px;
    border-radius: 8px;
    border: 1px solid #2ecc71;
}
.val {
    font-size: 2.2em;
    font-weight: bold;
    margin: 5px 0;
}
canvas {
    background: #000;
    width: 100%;
    max-width: 800px;
    height: 200px;
    border-radius: 8px;
    border: 2px solid #2ecc71;
    background-image:
        linear-gradient(#1a5331 1px, transparent 1px),
        linear-gradient(90deg, #1a5331 1px, transparent 1px);
    background-size: 20px 20px;
    box-shadow: 0 0 15px rgba(46, 204, 113, 0.3);
    margin-top: 5px;
}
button {
    padding: 10px 20px;
    border: none;
    border-radius: 6px;
    font-size: 1.1em;
    font-weight: bold;
    cursor: pointer;
    margin: 5px;
}
.btn-start { background-color: #27ae60; color: white; }
.btn-stop { background-color: #c0392b; color: white; }
.btn-report { background-color: #2980b9; color: white; display: none; }
.alert {
    color: #e74c3c;
    font-weight: bold;
    font-size: 1.1em;
    animation: blink 1s infinite;
    display: none;
    margin: 3px 0;
}
@keyframes blink { 50% { opacity: 0; } }
#estado_medicion {
    font-size: 1.1em;
    font-weight: bold;
    margin: 5px 0;
    color: #f1c40f;
}
.status-bajo { color: #3498db; }
.status-normal { color: #2ecc71; }
.status-alto { color: #e74c3c; }
</style>
</head>
<body>

<h2>Monitor Clínico - ECG & Postura</h2>

<div class="card" style="background: #1a1a1a;">
    <button class="btn-start" onclick="iniciarMedicion()">▶ INICIAR (20s)</button>
    <button class="btn-stop" onclick="fetch('/stop')">■ REINICIAR</button>
    <button id="btn_reporte" class="btn-report" onclick="descargarReporte()">📥 DESCARGAR REPORTE</button>
    <div id="estado_medicion">ESTADO: ESPERANDO</div>
    <div id="alerta_parches" class="alert">⚠️ ¡ELECTRODOS DESCONECTADOS! ⚠️</div>
</div>

<canvas id="ecgCanvas" width="800" height="200"></canvas>

<div class="grid">
    <div class="card">
        <h3>Frecuencia (BPM)</h3>
        <div class="val" id="v_bpm" style="color: #2ecc71;">--</div>
    </div>
    <div class="card">
        <h3>Ritmo Cardíaco</h3>
        <div class="val" id="v_clasificacion" style="font-size: 1.5em;">--</div>
    </div>
    <div class="card">
        <h3>Postura (MPU6050)</h3>
        <div class="val" id="v_postura" style="font-size: 1.3em; color: #3498db;">--</div>
        <div style="font-size: 0.9em; margin-top: 5px;" id="v_angulos">Roll: -- | Pitch: --</div>
        <div style="font-size: 0.8em; margin-top: 3px;" id="v_mpu_estado">Estado MPU: Desconectado</div>
    </div>
</div>

<script>
const canvas = document.getElementById('ecgCanvas');
const ctx = canvas.getContext('2d');
let x = 0;
ctx.lineWidth = 2.2;
ctx.strokeStyle = '#2ecc71';

let pointQueue = [];
let historialECG = [];
let fetchEnCurso = false;

function iniciarMedicion() {
    historialECG = []; // Limpiar historial anterior
    fetch('/start');
}

setInterval(() => {
    if (fetchEnCurso) return;
    fetchEnCurso = true;

    fetch('/data')
    .then(r => r.json())
    .then(d => {
        fetchEnCurso = false;
        let txtEst = document.getElementById('estado_medicion');
        let txtParches = document.getElementById('alerta_parches');
        let btnRep = document.getElementById('btn_reporte');

        txtParches.style.display = d.parches_desconectados ? 'block' : 'none';

        if (d.midiendo) {
            txtEst.innerText = "ESTADO: MIDIENDO (" + d.tiempo_restante + "s)";
            btnRep.style.display = 'none';
        } else if (d.completado) {
            txtEst.innerText = "ESTADO: MEDICIÓN FINALIZADA";
            btnRep.style.display = 'inline-block';
        } else {
            txtEst.innerText = "ESTADO: ESPERANDO INICIO";
            btnRep.style.display = 'none';
        }

        document.getElementById('v_bpm').innerText = d.bpm > 0 ? d.bpm : '--';
        let clasElem = document.getElementById('v_clasificacion');
        clasElem.innerText = d.clasificacion;
        clasElem.className = "val status-" + d.nivel_clase;

        document.getElementById('v_postura').innerText = d.mpu_conectado ? d.postura : 'Sin conexión';
        document.getElementById('v_angulos').innerText = `Roll: ${d.roll.toFixed(1)}° | Pitch: ${d.pitch.toFixed(1)}°`;
        let mpuEst = document.getElementById('v_mpu_estado');
        mpuEst.innerText = d.mpu_conectado ? "Estado MPU: Conectado" : "Estado MPU: Sin señal";
        mpuEst.style.color = d.mpu_conectado ? "#2ecc71" : "#e74c3c";

        if (d.puntos && d.puntos.length > 0) {
            pointQueue.push(...d.puntos);
            if (d.midiendo) {
                historialECG.push(...d.puntos);
            }
        }
    })
    .catch(e => {
        fetchEnCurso = false;
    });
}, 80);

function drawLoop() {
    if (pointQueue.length > 0) {
        let val = pointQueue.shift();
        let y = 200 - (((val * 1.5) / 4095) * 200);
        if (y < 0) y = 0;
        if (y > 200) y = 200;

        if (x >= canvas.width) {
            x = 0;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.beginPath();
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
            ctx.stroke();
        }
        x += 2;
    }
    requestAnimationFrame(drawLoop);
}
requestAnimationFrame(drawLoop);

function descargarReporte() {
    let ahora = new Date();
    let horaStr = ahora.toLocaleTimeString();
    let fechaStr = ahora.toLocaleDateString();

    let reporteCanvas = document.createElement('canvas');
    reporteCanvas.width = 900;
    reporteCanvas.height = 540;
    let rCtx = reporteCanvas.getContext('2d');

    rCtx.fillStyle = "#111";
    rCtx.fillRect(0, 0, 900, 540);

    rCtx.fillStyle = "#2ecc71";
    rCtx.font = "bold 22px Courier New";
    rCtx.fillText("REPORTE GRÁFICO INFORMATIVO - ECG & POSTURA", 50, 40);

    rCtx.font = "14px Courier New";
    rCtx.fillText("Fecha: " + fechaStr + " | Hora: " + horaStr, 50, 75);
    rCtx.fillText("Frecuencia Promedio (BPM): " + document.getElementById('v_bpm').innerText, 50, 105);
    rCtx.fillText("Ritmo Cardíaco: " + document.getElementById('v_clasificacion').innerText, 50, 130);
    rCtx.fillText("Última Postura Registrada: " + document.getElementById('v_postura').innerText, 50, 155);

    rCtx.strokeStyle = "#1a5331";
    rCtx.lineWidth = 1;
    for (let i = 0; i < 900; i += 30) {
        rCtx.beginPath();
        rCtx.moveTo(i, 190);
        rCtx.lineTo(i, 480);
        rCtx.stroke();
    }
    for (let j = 190; j < 480; j += 30) {
        rCtx.beginPath();
        rCtx.moveTo(50, j);
        rCtx.lineTo(850, j);
        rCtx.stroke();
    }

    rCtx.strokeStyle = "#2ecc71";
    rCtx.lineWidth = 2;
    rCtx.beginPath();
    let datosDibujo = historialECG.length > 0 ? historialECG : [2048];
    let stepX = 800 / (datosDibujo.length || 1);
    for (let i = 0; i < datosDibujo.length; i++) {
        let px = 50 + (i * stepX);
        let py = 480 - (((datosDibujo[i] * 1.5) / 4095) * 260);
        if (i === 0) {
            rCtx.moveTo(px, py);
        } else {
            rCtx.lineTo(px, py);
        }
    }
    rCtx.stroke();

    let link = document.createElement('a');
    let nombreArchivo = "Reporte_Grafico_" + ahora.getHours() + "-" + ahora.getMinutes() + ".png";
    link.download = nombreArchivo;
    link.href = reporteCanvas.toDataURL('image/png');
    link.click();
}
</script>
</body>
</html>
"""

# ==========================================
# 4. SERVIDOR WEB
# ==========================================
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('', 80))
s.listen(5)
s.setblocking(False)

# ==========================================
# 5. VARIABLES DE ESTADO
# ==========================================
bpm_est = 0
clasificacion_txt = "--"
nivel_clase = "normal"

ultimo_latido = 0
primer_latido_detectado = False
lista_bpm = []
buffer_ecg_muestras = []
buffer_grafica = []
ultimo_valor_filtrado = 2048

medicion_activa = False
medicion_completada = False
inicio_medicion = 0
tiempo_restante = 20
ultimo_muestreo = time.ticks_ms()

mpu_roll = 0.0
mpu_pitch = 0.0
mpu_postura = "Sin clasificar"
ultimo_ping_mpu = 0

# ==========================================
# 6. BUCLE PRINCIPAL
# ==========================================
while True:
    ahora_ms = time.ticks_ms()
    time.sleep_ms(2)  # Pausa breve para aliviar el procesador

    # --------------------------------------
    # ADQUISICIÓN ECG CADA 10 ms
    # --------------------------------------
    if time.ticks_diff(ahora_ms, ultimo_muestreo) >= 10:
        ultimo_muestreo = ahora_ms

        parches_sueltos = (
            lo_plus.value() == 1 or
            lo_minus.value() == 1
        )

        raw_ecg = adc.read()
        valor_ecg = int(
            0.5 * ultimo_valor_filtrado +
            0.5 * raw_ecg
        )
        ultimo_valor_filtrado = valor_ecg

        if not parches_sueltos:
            buffer_grafica.append(valor_ecg)
            if len(buffer_grafica) > 50:
                buffer_grafica.pop(0)

            if medicion_activa:
                buffer_ecg_muestras.append(valor_ecg)
                if len(buffer_ecg_muestras) > 35:
                    buffer_ecg_muestras.pop(0)
                    promedio_movil = sum(buffer_ecg_muestras) / len(buffer_ecg_muestras)

                    if valor_ecg > (promedio_movil + 350):
                        if not primer_latido_detectado:
                            ultimo_latido = ahora_ms
                            primer_latido_detectado = True
                        else:
                            diff = time.ticks_diff(ahora_ms, ultimo_latido)
                            if diff > 500:
                                bpm_inst = 60000 / diff
                                ultimo_latido = ahora_ms
                                
                                if 50 <= bpm_inst <= 140:
                                    lista_bpm.append(bpm_inst)
                                    if len(lista_bpm) > 5:
                                        lista_bpm.pop(0)

                                    bpm_est = int(sum(lista_bpm) / len(lista_bpm))

                                    if bpm_est < 60:
                                        clasificacion_txt = "BAJO"
                                        nivel_clase = "bajo"
                                    elif 60 <= bpm_est <= 100:
                                        clasificacion_txt = "NORMAL"
                                        nivel_clase = "normal"
                                    else:
                                        clasificacion_txt = "ALTO"
                                        nivel_clase = "alto"

    if medicion_activa:
        elapsed = time.ticks_diff(ahora_ms, inicio_medicion)
        tiempo_restante = 20 - (elapsed // 1000)

        if elapsed >= 20000:
            medicion_activa = False
            medicion_completada = True
            tiempo_restante = 0

    # --------------------------------------
    # SERVIDOR HTTP
    # --------------------------------------
    try:
        conn, addr = s.accept()
        peticion = conn.recv(1024).decode('utf-8')

        if 'GET /start' in peticion:
            medicion_activa = True
            medicion_completada = False
            inicio_medicion = time.ticks_ms()
            lista_bpm.clear()
            buffer_ecg_muestras.clear()
            bpm_est = 0
            clasificacion_txt = "--"
            nivel_clase = "normal"
            ultimo_latido = time.ticks_ms()
            primer_latido_detectado = False
            
            conn.send(b'HTTP/1.1 200 OK\r\nContent-Length: 0\r\nConnection: close\r\n\r\n')

        elif 'GET /stop' in peticion:
            medicion_activa = False
            medicion_completada = False
            lista_bpm.clear()
            buffer_ecg_muestras.clear()
            buffer_grafica.clear()
            bpm_est = 0
            clasificacion_txt = "--"
            nivel_clase = "normal"
            tiempo_restante = 20
            primer_latido_detectado = False
            
            conn.send(b'HTTP/1.1 200 OK\r\nContent-Length: 0\r\nConnection: close\r\n\r\n')

        elif 'POST /postura' in peticion:
            try:
                partes = peticion.split('\r\n\r\n')
                cabeceras = partes[0]
                cuerpo = partes[1] if len(partes) > 1 else ""

                content_length = 0
                for linea in cabeceras.split('\r\n'):
                    if linea.startswith('Content-Length:'):
                        content_length = int(linea.split(':')[1].strip())

                while len(cuerpo) < content_length:
                    datos_extra = conn.recv(1024)
                    if not datos_extra:
                        break
                    cuerpo += datos_extra.decode('utf-8')

                datos_mpu = json.loads(cuerpo)
                r = datos_mpu.get("roll")
                p = datos_mpu.get("pitch")
                pos = datos_mpu.get("postura")

                posturas_validas = ["Supino", "Lateral derecho", "Prono", "Lateral izquierdo", "Sin clasificar"]
                if isinstance(r, (int, float)) and isinstance(p, (int, float)) and pos in posturas_validas:
                    mpu_roll = float(r)
                    mpu_pitch = float(p)
                    mpu_postura = pos
                    ultimo_ping_mpu = time.ticks_ms()

                    respuesta_json = json.dumps({"status": "ok"})
                    resp_bytes = respuesta_json.encode('utf-8')
                    cabecera_resp = (
                        f"HTTP/1.1 200 OK\r\n"
                        f"Content-Type: application/json\r\n"
                        f"Content-Length: {len(resp_bytes)}\r\n"
                        f"Connection: close\r\n\r\n"
                    ).encode('utf-8')
                    conn.send(cabecera_resp + resp_bytes)
                else:
                    conn.send(b'HTTP/1.1 400 Bad Request\r\nContent-Length: 0\r\nConnection: close\r\n\r\n')
            except Exception:
                conn.send(b'HTTP/1.1 500 Internal Server Error\r\nContent-Length: 0\r\nConnection: close\r\n\r\n')

        elif 'GET /data' in peticion:
            parches_sueltos = (
                lo_plus.value() == 1 or
                lo_minus.value() == 1
            )

            puntos_a_enviar = list(buffer_grafica)
            buffer_grafica.clear()

            mpu_conectado = time.ticks_diff(ahora_ms, ultimo_ping_mpu) < 5000 if ultimo_ping_mpu > 0 else False

            datos = {
                "parches_desconectados": parches_sueltos,
                "midiendo": medicion_activa,
                "completado": medicion_completada,
                "tiempo_restante": tiempo_restante,
                "bpm": bpm_est,
                "clasificacion": clasificacion_txt,
                "nivel_clase": nivel_clase,
                "puntos": puntos_a_enviar,
                "roll": mpu_roll,
                "pitch": mpu_pitch,
                "postura": mpu_postura,
                "mpu_conectado": mpu_conectado
            }

            cuerpo_json = json.dumps(datos).encode('utf-8')
            cabecera_resp = (
                f"HTTP/1.1 200 OK\r\n"
                f"Content-Type: application/json\r\n"
                f"Content-Length: {len(cuerpo_json)}\r\n"
                f"Connection: close\r\n\r\n"
            ).encode('utf-8')
            conn.send(cabecera_resp + cuerpo_json)

        elif 'GET / ' in peticion or peticion.startswith('GET / HTTP'):
            html_bytes = html.encode('utf-8')
            cabecera_resp = (
                f"HTTP/1.1 200 OK\r\n"
                f"Content-Type: text/html\r\n"
                f"Content-Length: {len(html_bytes)}\r\n"
                f"Connection: close\r\n\r\n"
            ).encode('utf-8')
            conn.send(cabecera_resp + html_bytes)

        else:
            conn.send(b'HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n')

        conn.close()

    except OSError:
        pass