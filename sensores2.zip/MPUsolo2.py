from machine import Pin, SoftI2C
import time
import math
import network
import socket
import json

# =====================================
# 1. CONFIGURACION WI-FI (ESTACION STA)
# =====================================
SSID_RED = "ampeapp"
PASS_RED = "proyectouniversidad"
IP_SERVIDOR = "192.168.4.1"
PUERTO_SERVIDOR = 80

sta = network.WLAN(network.STA_IF)
sta.active(True)

print("Conectando a la red del ECG (ampeapp)...")

try:
    sta.connect(SSID_RED, PASS_RED)
except Exception as e:
    print("[Wi-Fi] Error inicial:", e)

intentos = 0
while not sta.isconnected() and intentos < 15:
    time.sleep_ms(500)
    print(".", end="")
    intentos += 1

if sta.isconnected():
    print("\n¡Conectado a la red con éxito!")
    print("IP asignada:", sta.ifconfig()[0])
else:
    print("\n[Wi-Fi] Sin conexión inicial. Se intentará reconectar durante la ejecución.")

ultimo_intento_wifi = time.ticks_ms()
INTERVALO_RECONEXION = 5000

# =====================================
# 2. CONFIGURACION Y VALIDACION MPU6050
# =====================================
i2c = SoftI2C(
    scl=Pin(22),
    sda=Pin(21),
    freq=100000
)

MPU_ADDR = 0x68

# Validación inicial de presencia del sensor en el bus I2C
try:
    dispositivos = i2c.scan()
    if MPU_ADDR in dispositivos:
        print("\n[MPU6050] Sensor detectado correctamente en la dirección 0x68.")
    else:
        print("\n[Advertencia] El MPU6050 no responde en la dirección 0x68. Revise el cableado.")
except Exception as e:
    print("\n[Error I2C] Fallo al escanear el bus:", e)

# Salir del modo de suspensión
i2c.writeto_mem(MPU_ADDR, 0x6B, b'\x00')
time.sleep_ms(200)

print("MONITOR DE POSTURA MPU6050 - ACTIVO")

# =====================================
# 3. CONVERSION Y CALCULO DE ANGULOS
# =====================================
def conv(high, low):
    valor = (high << 8) | low
    if valor >= 32768:
        valor -= 65536
    return valor

def leer_angulos():
    datos = i2c.readfrom_mem(MPU_ADDR, 0x3B, 6)
    ax = conv(datos[0], datos[1]) / 16384
    ay = conv(datos[2], datos[3]) / 16384
    az = conv(datos[4], datos[5]) / 16384

    roll = math.degrees(math.atan2(ay, az))
    pitch = math.degrees(math.atan2(-ax, math.sqrt(ay**2 + az**2)))
    return roll, pitch

# =====================================
# 4. CLASIFICACION DE POSTURA
# =====================================
def clasificar_postura(roll, pitch, postura_actual):
    if pitch <= -78:
        return "Supino"
    if abs(roll) <= 35 and pitch >= -5:
        return "Lateral derecho"
    if abs(roll) >= 145 and pitch >= 60:
        return "Prono"
    if abs(roll) >= 145 and -25 <= pitch <= 20:
        return "Lateral izquierdo"
    return postura_actual  # Persistencia de clasificación ante zonas de transición

# =====================================
# 5. RECONEXION WI-FI NO BLOQUEANTE
# =====================================
def verificar_wifi():
    global ultimo_intento_wifi
    if sta.isconnected():
        return True

    ahora = time.ticks_ms()
    if time.ticks_diff(ahora, ultimo_intento_wifi) >= INTERVALO_RECONEXION:
        print("[Wi-Fi] Desconectado. Intentando reconectar...")
        try:
            sta.connect(SSID_RED, PASS_RED)
        except Exception as e:
            print("[Wi-Fi] Error de reconexion:", e)
        ultimo_intento_wifi = ahora
    return False

# =====================================
# 6. ENVIO HTTP POST AL SERVIDOR ECG
# =====================================
def enviar_datos_servidor(roll, pitch, postura):
    if not verificar_wifi():
        return

    s = None
    try:
        cuerpo = json.dumps({
            "roll": round(roll, 2),
            "pitch": round(pitch, 2),
            "postura": postura
        }).encode("utf-8")

        encabezado = (
            "POST /postura HTTP/1.1\r\n"
            "Host: {}\r\n"
            "Content-Type: application/json\r\n"
            "Content-Length: {}\r\n"
            "Connection: close\r\n"
            "\r\n"
        ).format(IP_SERVIDOR, len(cuerpo)).encode("utf-8")

        peticion = encabezado + cuerpo

        addr = socket.getaddrinfo(IP_SERVIDOR, PUERTO_SERVIDOR)[0][-1]
        s = socket.socket()
        s.settimeout(0.8)
        s.connect(addr)

        enviados = 0
        while enviados < len(peticion):
            cantidad = s.send(peticion[enviados:])
            if cantidad <= 0:
                raise OSError("Envio incompleto de la peticion")
            enviados += cantidad

        respuesta = s.recv(512)
        if respuesta:
            respuesta = respuesta.decode("utf-8", "ignore")
            primera_linea = respuesta.split("\r\n")[0]
            if "200 OK" in primera_linea:
                print("[Red] Postura aceptada por el servidor ECG.")
            else:
                print("[Red] Respuesta del servidor:", primera_linea)
        else:
            print("[Red] El servidor no devolvio respuesta.")

    except Exception as e:
        print("[Red] Error de transmision:", e)
    finally:
        if s is not None:
            try:
                s.close()
            except:
                pass

# =====================================
# 7. BUCLE PRINCIPAL
# =====================================
postura_actual = "Sin clasificar"
contador_envio = 0

print("\nIniciando medicion continua...")
print("----------------------------------------")

while True:
    try:
        roll, pitch = leer_angulos()
        postura_actual = clasificar_postura(roll, pitch, postura_actual)

        # Salida numérica estricta para el Plotter de Thonny (cada 100 ms)
        print((roll, pitch))

        verificar_wifi()

        contador_envio += 1
        if contador_envio >= 10:
            # Imprimimos la postura en la consola de texto cada 1 segundo
            print("-> Postura detectada: {} (Roll: {:.2f}, Pitch: {:.2f})".format(
                postura_actual, roll, pitch
            ))

            enviar_datos_servidor(
                roll,
                pitch,
                postura_actual
            )

            contador_envio = 0

        # Intervalo nominal de adquisición: 100 ms
        time.sleep_ms(100)

    except OSError as e:
        print("[MPU6050] Error I2C:", e)
        time.sleep_ms(100)
    except Exception as e:
        print("[Sistema] Error inesperado:", e)
        time.sleep_ms(100)