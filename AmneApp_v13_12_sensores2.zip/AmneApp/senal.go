package main

import (
	"net/http"
	"strconv"
	"sync"

	"github.com/labstack/echo/v4"
)

// Señal ECG en vivo (AD8232). Vive solo en memoria y es independiente por paciente:
// lo que envía un dispositivo nunca se mezcla con el buffer de otro.
const (
	ecgFs         = 100  // Hz: el ESP32 muestrea cada 10 ms (igual que ECGsolo2.py)
	ecgMaxBuffer  = 1500 // muestras que conserva el servidor por paciente (15 s)
	ecgMaxVentana = 400  // máximo que entrega una consulta (4 s)
)

type bufSenal struct {
	seq   int64 // número total de muestras recibidas (la última muestra tiene índice seq)
	datos []int
}

var senales = struct {
	sync.Mutex
	m map[int]*bufSenal
}{m: map[int]*bufSenal{}}

func senalAgregar(idPaciente int, muestras []int) {
	if len(muestras) == 0 {
		return
	}
	senales.Lock()
	defer senales.Unlock()
	b := senales.m[idPaciente]
	if b == nil {
		b = &bufSenal{}
		senales.m[idPaciente] = b
	}
	b.datos = append(b.datos, muestras...)
	b.seq += int64(len(muestras))
	if len(b.datos) > ecgMaxBuffer {
		b.datos = append([]int(nil), b.datos[len(b.datos)-ecgMaxBuffer:]...)
	}
}

// senalDesde devuelve las muestras posteriores a `since` (máx. ecgMaxVentana) y el nuevo seq.
func senalDesde(idPaciente int, since int64) (int64, []int) {
	senales.Lock()
	defer senales.Unlock()
	b := senales.m[idPaciente]
	if b == nil {
		return 0, []int{}
	}
	n := b.seq - since
	if since < 0 || n < 0 || n > ecgMaxVentana { // primera consulta o servidor reiniciado
		n = ecgMaxVentana
	}
	if int(n) > len(b.datos) {
		n = int64(len(b.datos))
	}
	out := make([]int, n)
	copy(out, b.datos[len(b.datos)-int(n):])
	return b.seq, out
}

// HandlerSenal: GET /api/patients/:id/signal?since=N  ->  {fs, unit, seq, samples[]}
func HandlerSenal(c echo.Context) error {
	id, ok := pacienteAutorizado(c)
	if !ok {
		return nil
	}
	since, err := strconv.ParseInt(c.QueryParam("since"), 10, 64)
	if err != nil {
		since = -1
	}
	seq, muestras := senalDesde(id, since)
	return c.JSON(http.StatusOK, map[string]interface{}{"fs": ecgFs, "unit": "ADC", "seq": seq, "samples": muestras})
}
