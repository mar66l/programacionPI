ApneApp — monitoreo de apnea del sueño

Todo corre en un solo puerto (8084).

## Cómo ejecutarlo en tu computadora (Windows; en Mac/Linux es igual)
1. Instala Go desde https://go.dev/dl --> Verifica: abre una terminal y escribe `go version`.
2. Arranca: `go run .` — la primera vez descarga dependencias (necesita internet). Debe decir que escucha en `0.0.0.0:8084`.
3. Abre http://localhost:8084. Cuentas (contraseña = `SEED_PASSWORD` de tu `.env`):
   `doctor@redmedica.com` (médico) · `pacienteA@redmedica.com` (Don Roberto, paciente Tipo 1: pre-diagnóstico, sensor ECG AD8232) ·
   `pacienteB@redmedica.com` (Doña Elena, paciente Tipo 2: diagnosticada, giroscopio MPU6050) · `admin@redmedica.com` (administrador).
4. Averigua la IP de tu compu (`ipconfig` → "Dirección IPv4"), deja que Windows permita el
   puerto 8084 en el firewall (aparece un aviso al arrancar). La compu y **los dos ESP32 deben estar en la misma red Wi-Fi**
   (un router o el punto de acceso del celular; ya no se usa la red `ampeapp` de la placa ECG).
5. Cada placa lleva su propia `config.py` (copia de `esp32/config.example.py`): red, `SERVER_HOST` (IP de la compu), `DEVICE_ID`, `DEVICE_TOKEN` y `SENSOR`.
   - **ESP32_A** (paciente Tipo 1): sensor ECG AD8232 → `SENSOR="ecg"`, sube `main.py`, `sensor_ecg.py`, `config.py`. Token = `DEVICE_TOKEN_A`.
   - **ESP32_B** (paciente Tipo 2): MPU6050 → `SENSOR="mpu6050"`, sube `main.py`, `sensor_mpu.py`, `config.py`. Token = `DEVICE_TOKEN_B`.
6. **Dos perfiles a la vez:** abre `http://localhost:8084` en dos navegadores (p. ej. Chrome y Firefox, o una ventana normal y una de incógnito):
   en uno entra `pacienteA@redmedica.com` (ECG, pulso y alarma de pulso) y en el otro `pacienteB@redmedica.com` (ángulos roll/pitch, postura y alarma boca arriba).
   Si apagas un ESP32 o cierras una sesión, el otro perfil sigue igual. Sin hardware: `python herramientas/simulador_esp32.py`.
7. Si cambias un token en `.env`, reinicia el servidor (se actualiza solo). Si cambias el esquema, borra `sueno_seguro.db`.

## Si algo falla
- Pantalla en blanco o "No se puede conectar" → ¿está corriendo el servidor? ¿abriste `http://localhost:8084` y no el archivo suelto?
- El ESP32 recibe 401 → el `DEVICE_ID`/`DEVICE_TOKEN` no coinciden con `.env`; 422 → lectura fuera de rango o postura inválida.
- "Sin datos" en un paciente → su ESP32 aún no ha enviado nada (o no está asociado a ese paciente).
