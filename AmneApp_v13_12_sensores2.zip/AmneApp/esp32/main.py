# MicroPython (ESP32). Una lectura por segundo hacia el servidor Go: POST /api/telemetry.
# Sube a la placa: main.py, config.py (copia de config.example.py) y UN sensor:
#   ESP32_A -> sensor_ecg.py      ESP32_B -> sensor_mpu.py
# Cada placa trabaja sola: si una se apaga, la otra sigue enviando sin enterarse.
import network, socket, time, ujson, gc, _thread
from config import WIFI_SSID, WIFI_PASS, SERVER_HOST, SERVER_PORT, DEVICE_ID, DEVICE_TOKEN, SENSOR

if SENSOR == "ecg":
    from sensor_ecg import Sensor
else:
    from sensor_mpu import Sensor

INTERVALO_ENVIO_MS = 1000
MAX_PENDIENTES = 3          # si el servidor no responde, solo se guardan los últimos paquetes

sta = network.WLAN(network.STA_IF)
sta.active(True)
_ultimo_wifi = time.ticks_ms()


def wifi_ok():
    """Reconexión Wi-Fi no bloqueante (como en los scripts originales)."""
    global _ultimo_wifi
    if sta.isconnected():
        return True
    ahora = time.ticks_ms()
    if time.ticks_diff(ahora, _ultimo_wifi) >= 5000:
        _ultimo_wifi = ahora
        print("[Wi-Fi] conectando a", WIFI_SSID)
        try:
            sta.connect(WIFI_SSID, WIFI_PASS)
        except Exception as e:
            print("[Wi-Fi] error:", e)
    return False


def enviar(datos):
    """POST con socket y timeout. Devuelve el código HTTP (200 ok · 401 credencial · 422 datos inválidos) o None."""
    s = None
    try:
        cuerpo = ujson.dumps(datos).encode()
        cab = ("POST /api/telemetry HTTP/1.1\r\nHost: %s:%d\r\nContent-Type: application/json\r\n"
               "X-Device-Token: %s\r\nContent-Length: %d\r\nConnection: close\r\n\r\n"
               % (SERVER_HOST, SERVER_PORT, DEVICE_TOKEN, len(cuerpo))).encode()
        peticion = cab + cuerpo
        s = socket.socket()
        s.settimeout(3)
        s.connect(socket.getaddrinfo(SERVER_HOST, SERVER_PORT)[0][-1])
        enviados = 0
        while enviados < len(peticion):
            n = s.send(peticion[enviados:])
            if n <= 0:
                raise OSError("envío incompleto")
            enviados += n
        resp = s.recv(64)
        return int(resp[9:12]) if resp[:5] == b"HTTP/" else None
    except Exception as e:
        print("[Red] sin servidor:", e)       # no se inventan datos: simplemente no se envía
        return None
    finally:
        if s is not None:
            try:
                s.close()
            except Exception:
                pass


# El envío puede tardar (socket con timeout). Va en un hilo aparte para no perder muestras del ECG.
pendientes = []
cerrojo = _thread.allocate_lock()


def hilo_envio():
    while True:
        paquete = None
        cerrojo.acquire()
        if pendientes:
            paquete = pendientes[0]
        cerrojo.release()
        if paquete is None or not wifi_ok():
            time.sleep_ms(50)
            continue
        codigo = enviar(paquete)
        if codigo is not None:
            print("POST ->", codigo)
        if codigo is not None:                # el servidor respondió: ok o rechazo, no se reintenta
            cerrojo.acquire()
            if pendientes and pendientes[0] is paquete:
                pendientes.pop(0)
            cerrojo.release()
        else:
            time.sleep_ms(500)
        gc.collect()


sensor = Sensor()
_thread.stack_size(12 * 1024)
_thread.start_new_thread(hilo_envio, ())

ultimo_envio = time.ticks_ms()
print("Dispositivo", DEVICE_ID, "sensor", SENSOR, "-> http://%s:%d/api/telemetry" % (SERVER_HOST, SERVER_PORT))
while True:
    ahora = time.ticks_ms()
    sensor.paso(ahora)
    if time.ticks_diff(ahora, ultimo_envio) >= INTERVALO_ENVIO_MS:
        ultimo_envio = ahora
        datos = sensor.paquete()
        if datos is not None:
            datos["device_id"] = DEVICE_ID
            cerrojo.acquire()
            pendientes.append(datos)
            while len(pendientes) > MAX_PENDIENTES:
                pendientes.pop(0)
            cerrojo.release()
    time.sleep_ms(1)
