# Sensor de postura MPU6050 (ESP32). Lógica tomada de sensores2/MPUsolo2.py: mismos pines I2C,
# cálculo de roll/pitch y clasificación de postura (con persistencia en zonas de transición).
# Cambio: la postura se traduce al vocabulario del servidor (boca_arriba, boca_abajo, izquierdo, derecho).
from machine import Pin, SoftI2C
import math
import time

MPU_ADDR = 0x68
PERIODO_MS = 100         # lectura cada 100 ms; main.py envía la última cada 1 s
MAX_SIN_LECTURA_MS = 2000

# Nombre del sensor original -> valor que acepta el servidor
POSTURAS = {
    "Supino": "boca_arriba",
    "Prono": "boca_abajo",
    "Lateral derecho": "derecho",
    "Lateral izquierdo": "izquierdo",
    "Sin clasificar": "",
}


def _conv(high, low):
    v = (high << 8) | low
    return v - 65536 if v >= 32768 else v


def clasificar_postura(roll, pitch, actual):
    if pitch <= -78:
        return "Supino"
    if abs(roll) <= 35 and pitch >= -5:
        return "Lateral derecho"
    if abs(roll) >= 145 and pitch >= 60:
        return "Prono"
    if abs(roll) >= 145 and -25 <= pitch <= 20:
        return "Lateral izquierdo"
    return actual      # zona de transición: conserva la postura anterior


class Sensor:
    def __init__(self):
        self.i2c = SoftI2C(scl=Pin(22), sda=Pin(21), freq=100000)
        self.siguiente = time.ticks_ms()
        self.roll = 0.0
        self.pitch = 0.0
        self.postura = "Sin clasificar"
        self.ultima_ok = None          # ticks de la última lectura correcta
        self._iniciar()

    def _iniciar(self):
        try:
            if MPU_ADDR in self.i2c.scan():
                self.i2c.writeto_mem(MPU_ADDR, 0x6B, b'\x00')   # salir de suspensión
                time.sleep_ms(100)
                print("[MPU6050] detectado en 0x68")
                return True
            print("[MPU6050] no responde en 0x68. Revise el cableado.")
        except Exception as e:
            print("[MPU6050] error I2C:", e)
        return False

    def paso(self, ahora):
        if time.ticks_diff(ahora, self.siguiente) < 0:
            return
        self.siguiente = time.ticks_add(ahora, PERIODO_MS)
        try:
            d = self.i2c.readfrom_mem(MPU_ADDR, 0x3B, 6)
            ax = _conv(d[0], d[1]) / 16384
            ay = _conv(d[2], d[3]) / 16384
            az = _conv(d[4], d[5]) / 16384
            self.roll = math.degrees(math.atan2(ay, az))
            self.pitch = math.degrees(math.atan2(-ax, math.sqrt(ay * ay + az * az)))
            self.postura = clasificar_postura(self.roll, self.pitch, self.postura)
            self.ultima_ok = ahora
        except Exception:
            # Cable suelto o sensor caído: se intenta recuperar sin detener el programa
            if self.ultima_ok is None or time.ticks_diff(ahora, self.ultima_ok) > 1000:
                self._iniciar()

    def paquete(self):
        """None si el MPU6050 no está respondiendo: así no se envían datos inventados."""
        if self.ultima_ok is None or time.ticks_diff(time.ticks_ms(), self.ultima_ok) > MAX_SIN_LECTURA_MS:
            return None
        return {"posture": POSTURAS.get(self.postura, ""), "roll": round(self.roll, 2), "pitch": round(self.pitch, 2)}
