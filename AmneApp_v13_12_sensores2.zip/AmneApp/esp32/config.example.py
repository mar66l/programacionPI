# Copie como config.py en el ESP32 (config.py está en .gitignore). Un archivo DISTINTO por cada ESP32.
# La compu con el servidor Go y AMBOS ESP32 deben estar en la MISMA red Wi-Fi (router o punto de acceso del celular).
WIFI_SSID = "NombreDeSuRed"
WIFI_PASS = "ContraseñaDeSuRed"
SERVER_HOST = "192.168.1.10"      # IP de la compu con el servidor (ipconfig / ifconfig)
SERVER_PORT = 8084
DEVICE_ID = "ESP32_A"             # ESP32_A = ECG (paciente Tipo 1) · ESP32_B = MPU6050 (paciente Tipo 2)
DEVICE_TOKEN = "cambie-token-esp32-a"   # igual a DEVICE_TOKEN_A (o _B) del .env del servidor
SENSOR = "ecg"                    # "ecg" (AD8232, ESP32_A) o "mpu6050" (ESP32_B)
