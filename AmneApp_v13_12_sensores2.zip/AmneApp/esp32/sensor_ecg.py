# Sensor ECG AD8232 (ESP32). Lógica tomada de sensores2/ECGsolo2.py: mismos pines, muestreo a 100 Hz,
# detección de latidos y detección de electrodos desconectados. Cambios: ya no hay servidor web ni
# ventana de 20 s (mide de forma continua) y las muestras salen hacia el servidor Go desde main.py.
from machine import Pin, ADC
import time

PIN_ANALOGO = 34
PIN_LO_PLUS = 25
PIN_LO_MINUS = 26
PERIODO_MS = 10          # 100 Hz
UMBRAL_LATIDO = 350      # cuentas del ADC sobre el promedio móvil
SIN_LATIDO_MS = 4000     # si no hay latidos en 4 s, el pulso se considera "sin medición"


class Sensor:
    def __init__(self):
        self.adc = ADC(Pin(PIN_ANALOGO))
        self.adc.atten(ADC.ATTN_11DB)
        self.lo_plus = Pin(PIN_LO_PLUS, Pin.IN)
        self.lo_minus = Pin(PIN_LO_MINUS, Pin.IN)
        self.siguiente = time.ticks_ms()
        self.filtrado = 2048
        self.muestras = []        # lote pendiente de enviar (se vacía en paquete())
        self.ventana = []         # promedio móvil de 35 muestras
        self.lista_bpm = []
        self.bpm = 0
        self.ultimo_latido = 0
        self.primer_latido = False
        self.leads_off = False

    def paso(self, ahora):
        """Llamar muy seguido desde el bucle principal. Toma una muestra cada 10 ms."""
        if time.ticks_diff(ahora, self.siguiente) < 0:
            return
        self.siguiente = time.ticks_add(self.siguiente, PERIODO_MS)
        if time.ticks_diff(ahora, self.siguiente) > 100:      # nos atrasamos (envío lento): resincronizar
            self.siguiente = time.ticks_add(ahora, PERIODO_MS)

        self.leads_off = self.lo_plus.value() == 1 or self.lo_minus.value() == 1
        raw = self.adc.read()
        valor = int(0.5 * self.filtrado + 0.5 * raw)
        self.filtrado = valor

        if self.leads_off:
            # Sin electrodos no hay señal válida: se descarta y se reinicia el cálculo del pulso.
            self.ventana = []
            self.lista_bpm = []
            self.bpm = 0
            self.primer_latido = False
            return

        if len(self.muestras) < 300:
            self.muestras.append(valor)

        self.ventana.append(valor)
        if len(self.ventana) > 35:
            self.ventana.pop(0)
            promedio = sum(self.ventana) / len(self.ventana)
            if valor > promedio + UMBRAL_LATIDO:
                if not self.primer_latido:
                    self.ultimo_latido = ahora
                    self.primer_latido = True
                else:
                    diff = time.ticks_diff(ahora, self.ultimo_latido)
                    if diff > 500:
                        bpm_inst = 60000 / diff
                        self.ultimo_latido = ahora
                        if 50 <= bpm_inst <= 140:
                            self.lista_bpm.append(bpm_inst)
                            if len(self.lista_bpm) > 5:
                                self.lista_bpm.pop(0)
                            self.bpm = int(sum(self.lista_bpm) / len(self.lista_bpm))

        if self.primer_latido and time.ticks_diff(ahora, self.ultimo_latido) > SIN_LATIDO_MS:
            self.bpm = 0
            self.lista_bpm = []
            self.primer_latido = False

    def paquete(self):
        """Datos listos para enviar (una vez por segundo). Devuelve siempre algo: el ECG está conectado."""
        lote = self.muestras
        self.muestras = []
        return {"bpm": self.bpm, "leads_off": self.leads_off, "ecg": lote}
