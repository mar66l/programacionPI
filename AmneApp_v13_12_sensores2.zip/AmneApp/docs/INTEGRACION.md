# Integración: hallazgos, cambios y pendientes

## Lo que había en el repositorio original (y por qué no cumplía todo)
| # | Hallazgo | Requisito afectado |
|---|---|---|
| 1 | El login no devolvía token/sesión y **ningún endpoint pedía autenticación**: `/api/pacientes`, `/api/devices/status` y `/api/patients/:id/history` respondían a cualquiera. | Permisos comprobados en el servidor; no consultar datos ajenos |
| 2 | La pantalla decidía qué paciente ver en el navegador (`user.id === 2 ? 1 : 2`). La tabla `users` no estaba ligada a `pacientes`. | Asociación usuario–dispositivo validada en servidor |
| 3 | Tokens de dispositivo y contraseñas de prueba estaban escritos en `db.go` y los tokens en texto plano en la BD. | Claves fuera del código; credencial propia por dispositivo |
| 4 | No había rol administrador, confirmación de alertas, historial de eventos ni indicación real/simulado. | Roles, auditoría de cambios de asociación, fuente de los datos |
| 5 | `HandlerIndex` servía `htmltmpl/index.html` y `./assets`, que no existen en el repositorio. | Que el sistema arranque |
| 6 | **Ningún código de ESP32 enviaba a `/api/telemetry`**: `firmware.py` solo lee el MPU6050 e `indexHardware.py` es una página local del ESP32 (la rúbrica dice que una página aislada no demuestra integración). | Recepción real desde el ESP32 |
| 7 | `sketch_nov19b.ino` es de otro proyecto (EMG con servos). | "Sin archivos ajenos al proyecto" |
| 8 | Los sensores del repositorio son **MAX30102 (SpO₂/pulso) y MPU6050 (posición)**, no ECG. | Describir fielmente la tecnología usada |

## Qué se cambió
- **Backend (Go):** sesiones con token aleatorio (8 h), `RequireAuth` en toda la API de la pantalla, permisos por rol
  en el servidor (paciente solo lo suyo; médico y admin todos; admin gestiona dispositivos y auditoría), rol `admin`,
  `users.id_paciente`, `pacientes.tipo` (`pre`/`dx`), tokens de dispositivo guardados como hash SHA-256, secretos en `.env`,
  validación de posturas y rangos (422), alertas calculadas en el servidor, confirmación con silencio de 5 min, eventos,
  auditoría (login fallido, token inválido, acceso denegado, valores anómalos, cambio de asociación), campo `simulated`
  → `fuente` ("real"/"simulado"), horas en milisegundos. Base nueva: `sueno_seguro.db`.
- **Pantalla:** conectada a esta API; muestra SpO₂ y pulso (valores **medidos**), gráfica de las últimas 30 lecturas y
  "Sin dedo" en lugar de valores inventados; posición para el paciente diagnosticado; sin conexión si pasan >10 s.
- **ESP32:** `main.py` envía por Wi-Fi con su propio ID y token; el servidor decide a quién pertenece cada registro.

## API (resumen)
Pantalla (`Authorization: Bearer <token>`): `POST /api/auth/login {email,password}` · `POST /api/auth/logout` ·
`GET /api/patients` (médico, admin) · `GET /api/patients/:id/latest` · `GET /api/patients/:id/history` ·
`POST /api/patients/:id/alert/ack` · `GET /api/devices` y `POST /api/devices/:id/assign {userId}` (admin) · `GET /api/audit` (admin).
ESP32: `POST /api/telemetry` con `X-Device-Token` y `{device_id, spo2, bpm, posture, finger_detected, simulated?}`;
`posture`: `boca_arriba|boca_abajo|izquierdo|derecho|""`. Límites: SpO₂ 50–100 %, pulso 30–230 (solo con dedo).

## Pendiente (de ustedes)
1. **Driver del MAX30102** en `esp32/main.py` (`leer_max30102`): devolver SpO₂, pulso y si hay dedo.
2. **Calibrar la postura** del MPU6050 con pruebas reales (umbrales y orientación de montaje).
3. **Validar las reglas de alerta** (SpO₂ < 90 % con dedo; boca arriba) con su asesor y documentarlas; son de ejemplo.
4. La alerta que realmente no despierte de golpe debe salir del dispositivo (vibración suave creciente); la pantalla la refleja.
5. Médico ve **todos** los pacientes; si lo piden por médico asignado, hay que agregar una tabla `medico_paciente`.
6. Medir y anotar: frecuencia de adquisición (1 Hz en el ejemplo), intervalo de envío, `POLL_MS` (2 s) y retraso observado.
7. HTTPS y límite de intentos de login si se publica fuera de la red local (no es obligatorio).
8. Borrar `legacy_no_entregar/`, `.env` y `*.db` antes de entregar el ZIP.

## Actualización (segunda versión del repositorio)
- El equipo agregó el rol `admin` y los sensores por dispositivo: **ESP32_A = MAX30102 + AD8232 (ECG) → paciente Tipo 1**;
  **ESP32_B = MAX30102 + MPU6050 → paciente Tipo 2**. Esto corrige el punto 8 de la tabla anterior (sí hay ECG).
- **No integrar `/api/admin/overview` tal como está**: no pide sesión y devuelve `password_hash` de todos los usuarios.
  Esta versión cubre al administrador con `/api/patients`, `/api/devices` y `/api/audit` (todas con sesión y rol, sin hashes).
- **Pendiente ECG:** el ESP32 aún no envía muestras del AD8232 ni el servidor las recibe. La pantalla ya trae la gráfica y
  la pide a `GET /api/patients/:id/signal?since=N` (`{fs,unit,seq,samples[]}`, ver contrato del primer paquete); mientras
  no exista, muestra un aviso en lugar de inventar una señal.
- Los recordatorios del calendario se guardan solo en el navegador de cada persona; las alertas sí vienen del servidor.

## Actualización (integración de `sensores2`: ECG AD8232 + MPU6050)
Se reemplazaron los sensores del repositorio (MAX30102 ya no se usa) por los de `sensores2.zip`:
**ESP32_A = AD8232 (ECG) → paciente Tipo 1** y **ESP32_B = MPU6050 → paciente Tipo 2**.

**Qué se conservó de `ECGsolo2.py` / `MPUsolo2.py`:** pines, muestreo del ECG a 100 Hz con filtro, detección de latidos y pulso (promedio de 5),
clasificación BAJO < 60 / NORMAL 60–100 / ALTO > 100, detección de electrodos desconectados, cálculo de roll/pitch del MPU6050 y su clasificación de postura.

**Qué cambió y por qué:**
| Antes (`sensores2`) | Ahora | Motivo |
|---|---|---|
| El ECG era punto de acceso `ampeapp` y el MPU se conectaba a él | Ambos ESP32 se conectan a la misma red que la compu y envían a `POST /api/telemetry` con su token | Si el ECG se apagaba, el MPU quedaba sin red: no había perfiles independientes |
| Cada ESP32 servía su propia página web | Solo el frontend de AmneApp (un servidor, una sesión por navegador) | Un único punto de acceso con login y permisos |
| Medición de 20 s con botones INICIAR/REINICIAR y reporte PNG | Medición continua | Es monitoreo de sueño; no hay botones nuevos en la pantalla |
| Postura: Supino/Prono/Lateral… | `boca_arriba`/`boca_abajo`/`derecho`/`izquierdo` (la traducción la hace el ESP32) | Vocabulario que valida el servidor |

**Contrato de `POST /api/telemetry` (1 por segundo):** ECG `{device_id, bpm, leads_off, ecg:[muestras ADC 0–4095 a 100 Hz]}` · MPU `{device_id, posture, roll, pitch}`.
Rangos: pulso 0 o 30–230, roll −180…180, pitch −90…90, ≤ 400 muestras por envío (422 si no cumple).
`GET /api/patients/:id/signal?since=N` entrega las muestras ECG nuevas `{fs:100, unit:"ADC", seq, samples[]}` (en memoria, separadas por paciente).

**Alarmas (reglas de ejemplo, validarlas con su asesor):** Tipo 1: pulso BAJO (< 60) o ALTO (> 100) → alerta; electrodos desconectados → aviso "Coloque los electrodos" (sin alarma).
Tipo 2: postura boca arriba (Supino) → alerta. Se confirman con "Entendido" (silencio de 5 min) y quedan en el historial de eventos.

**Base de datos:** la telemetría está en la tabla nueva `telemetria_v2` (se crea sola). `telemetria_apnea` (SpO₂) ya no se usa. Se conserva 7 días.
