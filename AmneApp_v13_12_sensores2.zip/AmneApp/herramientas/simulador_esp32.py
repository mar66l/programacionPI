#!/usr/bin/env python3
"""Simula los DOS ESP32 enviando a la vez (sin hardware). Los datos se marcan como "simulado".
ESP32_A = ECG (AD8232): pulso, electrodos y muestras ADC a 100 Hz.  ESP32_B = MPU6050: roll, pitch y postura.
Uso:  python herramientas/simulador_esp32.py                (lee tokens y puerto del .env)
      python herramientas/simulador_esp32.py --sin-b 40    (ESP32_B deja de enviar a los 40 s: prueba de desconexión)
      python herramientas/simulador_esp32.py --sin-a 40    (ESP32_A deja de enviar a los 40 s)"""
import argparse, json, math, os, random, threading, time, urllib.request, urllib.error

def env(ruta):
    d = {}
    if os.path.exists(ruta):
        for l in open(ruta, encoding="utf-8"):
            l = l.strip()
            if l and not l.startswith("#") and "=" in l:
                k, v = l.split("=", 1); d[k.strip()] = v.strip().strip("\"'")
    return d

E = env(os.path.join(os.path.dirname(__file__), "..", ".env"))
ap = argparse.ArgumentParser()
ap.add_argument("--url", default="http://127.0.0.1:%s/api/telemetry" % E.get("PORT", "8084"))
ap.add_argument("--sin-a", type=int, default=0, help="segundos tras los cuales ESP32_A se desconecta")
ap.add_argument("--sin-b", type=int, default=0, help="segundos tras los cuales ESP32_B se desconecta")
a = ap.parse_args()
T0 = time.time()

def enviar(dev, tok, d):
    d.update(device_id=dev, simulated=True)
    r = urllib.request.Request(a.url, json.dumps(d).encode(), {"Content-Type": "application/json", "X-Device-Token": tok})
    try:
        with urllib.request.urlopen(r, timeout=3) as x: return x.status
    except urllib.error.HTTPError as e: return e.code
    except Exception as e: return str(e)

def g(p, c, w): return math.exp(-((p - c) ** 2) / (2 * w * w))
def ecg(p): return .1 * g(p, .15, .025) - .12 * g(p, .27, .008) + g(p, .30, .010) - .25 * g(p, .33, .010) + .25 * g(p, .55, .04)

def dispositivo_a():   # ECG: pulso bajo (52 lpm) entre los 20 y 35 s; electrodos sueltos entre 50 y 55 s
    fase = 0.0
    while True:
        t = time.time() - T0
        if a.sin_a and t > a.sin_a: print("ESP32_A desconectado"); return
        if 50 <= t % 70 < 55:
            d = {"bpm": 0, "leads_off": True, "ecg": []}
        else:
            bpm = 52 if 20 <= t % 70 < 35 else 66 + int(t) % 5
            muestras = []
            for _ in range(100):                       # 1 s de señal a 100 Hz
                fase = (fase + (bpm / 60) / 100) % 1
                muestras.append(int(max(0, min(4095, 1900 + 700 * ecg(fase) + random.uniform(-15, 15)))))
            d = {"bpm": bpm, "leads_off": False, "ecg": muestras}
        print("ESP32_A", {k: (v if k != "ecg" else "%d muestras" % len(v)) for k, v in d.items()}, "->", enviar("ESP32_A", E.get("DEVICE_TOKEN_A", ""), d)); time.sleep(1)

def dispositivo_b():   # MPU6050: boca arriba entre los 25 y 40 s; si no, de lado
    while True:
        t = time.time() - T0
        if a.sin_b and t > a.sin_b: print("ESP32_B desconectado"); return
        if 25 <= t % 70 < 40: d = {"posture": "boca_arriba", "roll": round(random.uniform(-5, 5), 2), "pitch": round(random.uniform(-88, -80), 2)}
        else: d = {"posture": "izquierdo", "roll": round(random.uniform(150, 170), 2), "pitch": round(random.uniform(-5, 10), 2)}
        print("ESP32_B", d, "->", enviar("ESP32_B", E.get("DEVICE_TOKEN_B", ""), d)); time.sleep(1)

for f in (dispositivo_a, dispositivo_b): threading.Thread(target=f, daemon=True).start()
while True: time.sleep(1)
