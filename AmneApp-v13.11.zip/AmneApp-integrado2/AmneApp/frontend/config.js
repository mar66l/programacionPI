// La pantalla la sirve el propio servidor Go (misma dirección y puerto), por eso BASE queda vacío.
// Para ver una demostración sin servidor cambie MODE a "mock".
window.APP_CONFIG = {
  MODE: "live", BASE: "",
  // Datos del responsable que aparecen en el Aviso de privacidad. COMPLÉTELOS antes de entregar.
  PRIV: {
    resp: "[Nombre completo del responsable]",
    dom:  "[Domicilio del responsable]",
    mail: "[correo para solicitudes de privacidad]"
  }
};
 