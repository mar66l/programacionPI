# MicroPython (ESP32). Envía una lectura por segundo al servidor Go.
# Sube a la placa: main.py, firmware.py (MPU6050) y config.py (copia de config.example.py).
import network, time, urequests, ujson
from config import WIFI_SSID, WIFI_PASS, SERVER_URL, DEVICE_ID, DEVICE_TOKEN, SENSOR

if SENSOR == "mpu6050":
    from firmware import inicializar_mpu, leer_angulos_sueno
    inicializar_mpu()


def conectar():
    w = network.WLAN(network.STA_IF)
    w.active(True)
    if not w.isconnected():
        w.connect(WIFI_SSID, WIFI_PASS)
        t = time.time()
        while not w.isconnected() and time.time() - t < 20:
            time.sleep(0.3)
    return w.isconnected()


def postura(giro):
    # Convención de firmware.py: 0° boca arriba, ±90° de lado, ±180° boca abajo.
    # CALIBRAR según cómo quede fijado el MPU6050 en el cuerpo.
    a = abs(giro)
    if a < 45:
        return "boca_arriba"
    if a > 135:
        return "boca_abajo"
    return "derecho" if giro > 0 else "izquierdo"


def leer_max30102():
    """TODO: devolver (spo2, bpm, dedo_detectado) usando el driver del MAX30102 que ya tengan.
    Si no hay dedo, devolver (0, 0, False): el servidor NO guarda valores inventados."""
    return 0.0, 0.0, False


def enviar(payload):
    try:
        r = urequests.post(SERVER_URL, data=ujson.dumps(payload),
                           headers={"Content-Type": "application/json", "X-Device-Token": DEVICE_TOKEN})
        print("POST ->", r.status_code)     # 200 ok | 401 credencial | 422 datos fuera de límites
        r.close()
    except Exception as e:
        print("Sin servidor:", e)           # no se inventan datos: simplemente no se envía


while True:
    if not conectar():
        time.sleep(2)
        continue
    if SENSOR == "mpu6050":
        giro, _ = leer_angulos_sueno()
        datos = {"posture": postura(giro), "spo2": 0, "bpm": 0, "finger_detected": False}
    else:
        spo2, bpm, dedo = leer_max30102()
        datos = {"posture": "", "spo2": spo2, "bpm": bpm, "finger_detected": dedo}
    datos["device_id"] = DEVICE_ID
    enviar(datos)
    time.sleep(1)
