# Copie como config.py en el ESP32 (config.py está en .gitignore). Un archivo DISTINTO por cada ESP32.
WIFI_SSID = "NombreDeSuRed"
WIFI_PASS = "ContraseñaDeSuRed"
SERVER_URL = "http://192.168.1.10:8084/api/telemetry"   # IP de la compu con el servidor (ipconfig)
DEVICE_ID = "ESP32_A"                                    # ESP32_B en el otro dispositivo
DEVICE_TOKEN = "cambie-token-esp32-a"                    # igual a DEVICE_TOKEN_A (o _B) del .env del servidor
SENSOR = "max30102"                                      # "max30102" (pre-diagnóstico) o "mpu6050" (diagnosticado)
