# Tabla de pruebas (completen "Obtenido" y "Correcciones" con evidencia: captura o salida de `test_api.py`)

| # | Prueba | Evidencia esperada | Obtenido | Correcciones |
|---|---|---|---|---|
| 1 | Inicio de sesión válido e inválido | Acceso correcto y rechazo controlado | | |
| 2 | Cierre de sesión | Las funciones privadas dejan de estar disponibles | | |
| 3 | Dos usuarios y dos ESP32 simultáneos | Datos separados y actualización automática | | |
| 4 | Acceso a datos ajenos sin permiso | El servidor rechaza (403) | | |
| 5 | Dispositivo sin credencial válida | No se aceptan sus datos (401) | | |
| 6 | Datos inválidos | Se rechazan (422) sin guardarse como válidos | | |
| 7 | Desconexión de un ESP32 | Se indica la falta de datos; el otro continúa | | |
| 8 | Reconexión del dispositivo | Se reanuda sin mezclar usuarios | | |
| 9 | Consulta posterior del historial | Registros asociados al usuario y dispositivo correctos | | |
| 10 | Alerta boca arriba (tipo dx) | Aviso suave en pantalla y evento en el historial | | |
| 11 | Alerta de ECG (tipo pre) | Aviso suave y evento; regla documentada | | |
| 12 | Cambio de asociación de dispositivo (admin) | Queda en auditoría; conflicto → 409 | | |

Mediciones a anotar en el informe: frecuencia de adquisición (Hz), intervalo de envío (s), intervalo de actualización de
pantalla (`POLL_MS`), retraso observado (de la lectura a la pantalla) y quién/qué fuente (real o simulada) generó cada dato.
