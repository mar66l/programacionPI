#!/usr/bin/env python3
"""Simula los DOS ESP32 enviando a la vez (sin hardware). Los datos se marcan como "simulado".
Uso:  python herramientas/simulador_esp32.py            (lee tokens y puerto del .env)
      python herramientas/simulador_esp32.py --sin-b 40  (el ESP32_B deja de enviar a los 40 s: prueba de desconexión)"""
import argparse, json, os, threading, time, urllib.request, urllib.error

def env(ruta):
    d = {}
    if os.path.exists(ruta):
        for l in open(ruta, encoding="utf-8"):
            l = l.strip()
            if l and not l.startswith("#") and "=" in l:
                k, v = l.split("=", 1); d[k.strip()] = v.strip().strip("\"'")
    return d

E = env(os.path.join(os.path.dirname(__file__), "..", ".env"))
ap = argparse.ArgumentParser()
ap.add_argument("--url", default="http://127.0.0.1:%s/api/telemetry" % E.get("PORT", "8084"))
ap.add_argument("--sin-b", type=int, default=0, help="segundos tras los cuales ESP32_B se desconecta")
a = ap.parse_args()
T0 = time.time()

def enviar(dev, tok, d):
    d.update(device_id=dev, simulated=True)
    r = urllib.request.Request(a.url, json.dumps(d).encode(), {"Content-Type": "application/json", "X-Device-Token": tok})
    try:
        with urllib.request.urlopen(r, timeout=3) as x: return x.status
    except urllib.error.HTTPError as e: return e.code
    except Exception as e: return str(e)

def dispositivo_a():   # paciente pre-diagnóstico: SpO2 baja entre los 20 y 35 s; sin dedo entre 50 y 55 s
    while True:
        t = time.time() - T0
        if 50 <= t % 70 < 55: d = {"spo2": 0, "bpm": 0, "finger_detected": False, "posture": ""}
        else: d = {"spo2": 86 if 20 <= t % 70 < 35 else 96, "bpm": 66 + int(t) % 5, "finger_detected": True, "posture": ""}
        print("ESP32_A", d, "->", enviar("ESP32_A", E.get("DEVICE_TOKEN_A", ""), d)); time.sleep(1)

def dispositivo_b():   # paciente diagnosticado: boca arriba entre los 25 y 40 s
    while True:
        t = time.time() - T0
        if a.sin_b and t > a.sin_b: print("ESP32_B desconectado"); return
        d = {"spo2": 0, "bpm": 0, "finger_detected": False, "posture": "boca_arriba" if 25 <= t % 70 < 40 else "izquierdo"}
        print("ESP32_B", d, "->", enviar("ESP32_B", E.get("DEVICE_TOKEN_B", ""), d)); time.sleep(1)

for f in (dispositivo_a, dispositivo_b): threading.Thread(target=f, daemon=True).start()
while True: time.sleep(1)
