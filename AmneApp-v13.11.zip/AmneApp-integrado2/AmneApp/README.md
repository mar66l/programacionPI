ApneApp — monitoreo de apnea del sueño

Todo corre en un solo puerto (8084).

## Cómo ejecutarlo en tu computadora (Windows; en Mac/Linux es igual)
1. Instala Go desde https://go.dev/dl --> Verifica: abre una terminal y escribe `go version`.
2. Arranca: `go run .` — la primera vez descarga dependencias (necesita internet). Debe decir que escucha en `0.0.0.0:8084`.
3. Abre http://localhost:8084. Cuentas (contraseña = `SEED_PASSWORD` de tu `.env`):
   `doctor@redmedica.com` (médico) · `pacienteA@redmedica.com` (Don Roberto, paciente Tipo 1: pre-diagnóstico, ECG + oxímetro) ·
   `pacienteB@redmedica.com` (Doña Elena, paciente Tipo 2: diagnosticada, giroscopio + oxímetro) · `admin@redmedica.com` (administrador).
4. Averigua la IP de tu compu (`ipconfig` → "Dirección IPv4"), deja que Windows permita el
   puerto 8084 en el firewall (aparece un aviso al arrancar), y en cada placa copia `esp32/config.example.py` como
   `config.py` con su propia red, `SERVER_URL=http://<IP>:8084/api/telemetry`, `DEVICE_ID`, `DEVICE_TOKEN` y `SENSOR`.
   Sube `main.py`, `firmware.py` y `config.py`. La compu y los ESP32 deben estar en la **misma red Wi-Fi**.
7. Si cambias un token en `.env`, reinicia el servidor (se actualiza solo). Si cambias el esquema, borra `sueno_seguro.db`.

## Si algo falla
- Pantalla en blanco o "No se puede conectar" → ¿está corriendo el servidor? ¿abriste `http://localhost:8084` y no el archivo suelto?
- El ESP32 recibe 401 → el `DEVICE_ID`/`DEVICE_TOKEN` no coinciden con `.env`; 422 → lectura fuera de rango o postura inválida.
- "Sin datos" en un paciente → su ESP32 aún no ha enviado nada (o no está asociado a ese paciente).
