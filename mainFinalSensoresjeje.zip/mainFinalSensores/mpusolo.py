from machine import Pin, SoftI2C
import time
import math
import network
import urequests
import ujson

WIFI_SSID = "zadekoo"
WIFI_PASS = "AndreaCastro11"
SERVER_URL = "http://192.168.32.104:8084/api/telemetry"
DEVICE_ID = "ESP32_B"
DEVICE_TOKEN = "token_mpu_456"

sta = network.WLAN(network.STA_IF)
sta.active(True)
sta.config(pm=sta.PM_NONE)

def verificar_wifi():
    if sta.isconnected():
        return True
    print("[Wi-Fi] Conectando a", WIFI_SSID, "...")
    try:
        sta.active(False)
        time.sleep_ms(100)
        sta.active(True)
        sta.connect(WIFI_SSID, WIFI_PASS)
        intentos = 0
        while not sta.isconnected() and intentos < 25:
            time.sleep_ms(200)
            intentos += 1
    except Exception as e:
        print("[Wi-Fi] Error:", e)
    if sta.isconnected():
        print("[Wi-Fi] Conectado! IP:", sta.ifconfig()[0])
        return True
    print("[Wi-Fi] No se pudo conectar")
    return False

i2c = SoftI2C(scl=Pin(22), sda=Pin(21), freq=100000)
MPU_ADDR = 0x68

try:
    if MPU_ADDR in i2c.scan():
        i2c.writeto_mem(MPU_ADDR, 0x6B, b'\x00')
        time.sleep_ms(100)
    else:
        print("[I2C] MPU6050 no detectado en 0x68")
except Exception as e:
    print("[I2C] Error:", e)

def conv(high, low):
    valor = (high << 8) | low
    return valor - 65536 if valor >= 32768 else valor

def leer_angulos():
    datos = i2c.readfrom_mem(MPU_ADDR, 0x3B, 6)
    ax = conv(datos[0], datos[1]) / 16384.0
    ay = conv(datos[2], datos[3]) / 16384.0
    az = conv(datos[4], datos[5]) / 16384.0
    roll = math.degrees(math.atan2(ay, az))
    pitch = math.degrees(math.atan2(-ax, math.sqrt(ay**2 + az**2)))
    return round(roll, 1), round(pitch, 1)

def clasificar_postura(roll, pitch, postura_actual):
    if pitch <= -65:
        return "boca_arriba"
    if pitch >= 65:
        return "boca_abajo"
    if -45 < pitch < 45 and abs(roll) <= 45:
        return "derecho"
    if -45 < pitch < 45 and abs(roll) >= 135:
        return "izquierdo"
    return postura_actual

def enviar_telemetria(postura, roll, pitch):
    if not verificar_wifi():
        return
    payload = {
        "device_id": DEVICE_ID,
        "posture": postura,
        "roll": roll,
        "pitch": pitch,
        "simulated": False
    }
    headers = {
        "Content-Type": "application/json",
        "X-Device-Token": DEVICE_TOKEN
    }
    r = None
    try:
        r = urequests.post(SERVER_URL, data=ujson.dumps(payload), headers=headers)
        print(f"[POST {DEVICE_ID}] {postura} | Roll:{roll} Pitch:{pitch} -> HTTP {r.status_code}")
    except Exception as e:
        print(f"[POST {DEVICE_ID}] Error:", e)
    finally:
        if r is not None:
            r.close()

verificar_wifi()
postura_actual = "boca_arriba"
roll, pitch = 0.0, 0.0
ultimo_muestreo = time.ticks_ms()
ultimo_envio = time.ticks_ms()

while True:
    ahora_ms = time.ticks_ms()

    if time.ticks_diff(ahora_ms, ultimo_muestreo) >= 50:
        ultimo_muestreo = ahora_ms
        try:
            roll, pitch = leer_angulos()
            postura_actual = clasificar_postura(roll, pitch, postura_actual)
        except Exception:
            pass

    if time.ticks_diff(ahora_ms, ultimo_envio) >= 1000:
        ultimo_envio = ahora_ms
        enviar_telemetria(postura_actual, roll, pitch)

    time.sleep_ms(2)