from machine import Pin, ADC
import time
import network
import urequests
import ujson

WIFI_SSID = "zadekoo"
WIFI_PASS = "AndreaCastro11"
SERVER_URL = "http://192.168.32.104:8084/api/telemetry"
DEVICE_ID = "ESP32_A"
DEVICE_TOKEN = "token_ecg_123"

sta = network.WLAN(network.STA_IF)
sta.active(True)

def verificar_wifi():
    if sta.isconnected ():
        return True
    print("[Wi-Fi] Conectando a", WIFI_SSID, "...")
    try:
        sta.connect(WIFI_SSID, WIFI_PASS)
        intentos = 0
        while not sta.isconnected() and intentos < 20:
            time.sleep_ms(300)
            intentos += 1
    except Exception as e:
        print("[Wi-Fi] Error:", e)
    if sta.isconnected():
        print("[Wi-Fi] Conectado! IP:", sta.ifconfig()[0])
        return True
    return False

adc = ADC(Pin(34))
adc.atten(ADC.ATTN_11DB)

lo_plus = Pin(25, Pin.IN)
lo_minus = Pin(26, Pin.IN)

def enviar_telemetria(bpm, electrodos_ok):
    if not verificar_wifi():
        return

    senal_valida = electrodos_ok and (30 <= bpm <= 230)

    payload = {
        "device_id": DEVICE_ID,
        "spo2": 98.0 if senal_valida else 0.0,
        "bpm": float(bpm) if senal_valida else 0.0,
        "posture": "",
        "finger_detected": senal_valida,
        "simulated": False
    }
    headers = {
        "Content-Type": "application/json",
        "X-Device-Token": DEVICE_TOKEN
    }
    r = None
    try:
        r = urequests.post(SERVER_URL, data=ujson.dumps(payload), headers=headers)
        print(f"[POST {DEVICE_ID}] BPM: {bpm} (Parches OK: {electrodos_ok}) -> HTTP {r.status_code}")
    except Exception as e:
        print("[HTTP Error]:", e)
    finally:
        if r is not None:
            r.close()

bpm_est = 0
ultimo_latido = 0
primer_latido_detectado = False
lista_bpm = []
buffer_ecg_muestras = []
ultimo_valor_filtrado = 2048

ultimo_muestreo = time.ticks_ms()
ultimo_envio = time.ticks_ms()

while True:
    ahora_ms = time.ticks_ms()

    # Muestreo cada 10 ms (100 Hz)
    if time.ticks_diff(ahora_ms, ultimo_muestreo) >= 10:
        ultimo_muestreo = ahora_ms

        parches_sueltos = (lo_plus.value() == 1 or lo_minus.value() == 1)
        raw_ecg = adc.read()
        valor_ecg = int(0.5 * ultimo_valor_filtrado + 0.5 * raw_ecg)
        ultimo_valor_filtrado = valor_ecg

        # Imprime solo el valor numérico para el Plotter de Thonny
        print(valor_ecg)

        if parches_sueltos:
            bpm_est = 0
            lista_bpm.clear()
            buffer_ecg_muestras.clear()
            primer_latido_detectado = False
        else:
            buffer_ecg_muestras.append(valor_ecg)
            if len(buffer_ecg_muestras) > 35:
                buffer_ecg_muestras.pop(0)
                promedio_movil = sum(buffer_ecg_muestras) / len(buffer_ecg_muestras)

                if valor_ecg > (promedio_movil + 350):
                    if not primer_latido_detectado:
                        ultimo_latido = ahora_ms
                        primer_latido_detectado = True
                    else:
                        diff = time.ticks_diff(ahora_ms, ultimo_latido)
                        if diff > 400:  # Permite detectar hasta 150 BPM sin retraso
                            bpm_inst = 60000 / diff
                            ultimo_latido = ahora_ms
                            if 50 <= bpm_inst <= 160:
                                lista_bpm.append(bpm_inst)
                                if len(lista_bpm) > 2:  # Promedio de 2 latidos (menos delay)
                                    lista_bpm.pop(0)
                                bpm_est = int(sum(lista_bpm) / len(lista_bpm))

    # Envío al servidor cada 1500 ms para dejar respirar la gráfica
    if time.ticks_diff(ahora_ms, ultimo_envio) >= 1500:
        ultimo_envio = ahora_ms
        parches_ok = not (lo_plus.value() == 1 or lo_minus.value() == 1)
        enviar_telemetria(bpm_est, parches_ok)

    time.sleep_ms(2)